package com.example.smartofficecontrol;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnInstitute, btnOffice, btnStaff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnInstitute = findViewById(R.id.btnInstitute);
        btnOffice = findViewById(R.id.btnOffice);
        btnStaff = findViewById(R.id.btnStaff);

        btnInstitute.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this, LoginActivity.class);
            i.putExtra("role", "Institute");
            startActivity(i);
        });

        btnOffice.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this, LoginActivity.class);
            i.putExtra("role", "Office");
            startActivity(i);
        });

        btnStaff.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this, LoginActivity.class);
            i.putExtra("role", "Staff");
            startActivity(i);
        });
    }
}