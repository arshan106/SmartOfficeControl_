package com.example.smartofficecontrol;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    TextView txtRole;
    EditText edtName;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        txtRole = findViewById(R.id.txtRole);
        edtName = findViewById(R.id.edtName);
        btnLogin = findViewById(R.id.btnLogin);

        String role = getIntent().getStringExtra("role");
        txtRole.setText(role + " Login");

        btnLogin.setOnClickListener(v -> {
            String name = edtName.getText().toString().trim();
            if (name.isEmpty()) {
                Toast.makeText(this, "Please enter name", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Welcome " + name, Toast.LENGTH_LONG).show();
            }
        });
    }
}
